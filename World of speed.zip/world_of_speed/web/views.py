from django.shortcuts import render, redirect

from world_of_speed.profile_app.models import Profile
from world_of_speed.web.forms import CreateProfileForm


def get_profile():
    return Profile.objects.first()


def create_profile(request):
    form = CreateProfileForm(request.POST or None)

    if form.is_valid():
        form.save()
        return redirect('web/catalogue.html')

    context = {
        "form": form,
    }
    return render(request, template_name='web/index.html', context=context)


def index(request):
    profile = get_profile()

    if profile is None:
        return create_profile(request)

    return render(request, template_name='web/catalogue.html')

