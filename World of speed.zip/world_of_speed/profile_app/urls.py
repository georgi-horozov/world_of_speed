from django.urls import path

from world_of_speed.profile_app.views import CreateProfileView

urlpatterns = (
    path('create/', CreateProfileView.as_view(), name='create_profile'),
)