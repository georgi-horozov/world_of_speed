from django.urls import path

from world_of_speed.cars.views import CreateCarView

urlpatterns = (
    path("create/", CreateCarView.as_view(), name="create_car"),
    path("<int:pk>/details/", DetailCarView.as_view(), name='detail_car'),
)